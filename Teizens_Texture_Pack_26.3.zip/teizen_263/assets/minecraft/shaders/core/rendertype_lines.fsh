#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    vec4 color = vertexColor * ColorModulator;

    // Teizen: Regenbogen-Blockumrandung (schwarze, halbdurchsichtige Linien)
    if (color.r == 0.0 && color.g == 0.0 && color.b == 0.0 && color.a < 0.5) {
        const float PI = 3.14159265359;
        float t = (gl_FragCoord.x + gl_FragCoord.y) * 0.01 + GameTime * 2000.0;
        color = vec4(abs(sin(t)), abs(sin(t + PI / 3.0)), abs(sin(t + 2.0 * PI / 3.0)), 1.0);
    }
    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
