SCULK APPLES v5 – 3D Sculk Golden Apple + Crystal Apple (Enchanted)

EIGENSTÄNDIG: Dieses Pack braucht das Eating Animation Pack NICHT (alle Modelle, Texturen und Bissstufen sind enthalten).
Wenn du beide benutzt, muss dieses Pack in der Liste ÜBER dem Eating Animation Pack stehen. Danach F3+T.
Alte Sculk-Apples-Packs (v1–v4) bitte deaktivieren.

GOLDEN APPLE (normal) – dunkler Sculk-Voxel-Apfel
• Echtes 3D-Modell aus Voxeln: dunkles Teal, Gold an Rand und einzelnen Stellen, leuchtende Cyan-Adern,
  Cyan-Blatt, kleine Funken drumherum.
• Animationen (bewusst dezent, damit man ihn vom Enchanted Apple unterscheiden kann):
  1. Cyan-Adern pulsieren versetzt (leuchten nacheinander auf)
  2. Ein Gold-Glanz wandert einmal pro Durchlauf diagonal über den Apfel
  3. Funken schweben nach oben und blinken
  4. Ein Lichtpunkt läuft über das Blatt
• Essen: 3 Bissstufen als eigene 3D-Modelle (Fruchtfleisch in Gold mit Cyan-Kristallen), Zeitsteuerung wie beim Enchanted Apple.

ENCHANTED GOLDEN APPLE – Kristall-Apfel (violett/blau, Energiering mit Kometen, pulsierender Kern) – unverändert aus v3.

DATEIEN
assets/minecraft/items/golden_apple.json, enchanted_golden_apple.json
assets/sculkapple/models/item/golden_apple*.json, crystal_apple*.json
assets/sculkapple/textures/item/golden_apple.png (+.mcmeta), crystal_apple.png (+.mcmeta)
