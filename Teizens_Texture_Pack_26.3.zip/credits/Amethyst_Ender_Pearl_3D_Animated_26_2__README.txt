Amethyst Ender Pearl 3D – Minecraft Java 26.2

Ender Pearl als 3D-Amethyst-Stern: Voxel-Kristall mit sechs Spitzen (goldene Spitzen wie in der Vorlage),
goldene Diagonal-Splitter, zwei kreisende Ringe (Gold + Lila) und schwebende Funken.
Animiert (Textur): Glanz wandert nacheinander über die Spitzen, Gold-Spitzen funkeln, Ringe mit zwei Kometen,
Kern pulsiert, Funken blinken. 32 Frames, 2 Ticks pro Frame.

Dateien: items/ender_pearl.json -> amethystpearl:item/amethyst_pearl (eigener Namespace, nichts anderes wird verändert).
Installation: ZIP in resourcepacks, aktivieren, F3+T. Mit anderen Packs kombinierbar (nur ender_pearl betroffen).
